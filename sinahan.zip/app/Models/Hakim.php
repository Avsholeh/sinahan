<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;

class Hakim extends BaseModel
{
    use HasFactory;

    protected $table = 'hakim';
}
