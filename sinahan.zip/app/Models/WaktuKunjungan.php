<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;

class WaktuKunjungan extends BaseModel
{
    use HasFactory;

    protected $table = 'waktu_kunjungan';
}
