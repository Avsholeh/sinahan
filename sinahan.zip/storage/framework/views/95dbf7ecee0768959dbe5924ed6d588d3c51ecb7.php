<ul class="navbar-nav bg-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Logo -->
    <a style="height: auto" class="sidebar-brand d-flex align-items-center justify-content-center flex-column"
       href="<?php echo e(route('home')); ?>">
        <div class="sidebar-brand-icon bg-white rounded mb-2">
            <img src="<?php echo e(asset('img/logo.png')); ?>" width="50">
        </div>
        <div class="sidebar-brand-text mx-3"><?php echo e(config('app.name')); ?></div>
        <small>Sistem Informasi Layanan Tahanan</small>
    </a>
    <!-- END Logo -->

    <hr class="sidebar-divider my-3">

    <div class="sidebar-heading">
        <?php echo e(__('layouts.utama')); ?>

    </div>
    <li class="nav-item<?php echo e(request()->is('dashboard') ? ' active' : ''); ?>">
        <a class="nav-link " href="<?php echo e(route('dashboard.index')); ?>">
            <i class="fas fa-fw fa-home"></i>
            <span><?php echo e(__('layouts.dashboard')); ?></span>
        </a>
    </li>

    <li class="nav-item<?php echo e(request()->is('biodata') ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('biodata.index')); ?>">
            <i class="fas fa-fw fa-home"></i>
            <span><?php echo e(__('layouts.biodata')); ?></span>
        </a>
    </li>

    <li class="nav-item<?php echo e(request()->is('kunjungan') || request()->is('kunjungan/*') ? ' active' : ''); ?>">
        <a class="nav-link collapsed" href="javascript:void(0)" data-toggle="collapse" data-target="#kunjungan"
           aria-expanded="false"
           aria-controls="kunjungan">
            <i class="fas fa-fw fa-business-time"></i>
            <span><?php echo e(__('layouts.kunjungan')); ?></span>
        </a>
        <div id="kunjungan" class="collapse<?php echo e(request()->is('kunjungan') || request()->is('kunjungan/*') ? ' show' : ''); ?>"
             aria-labelledby="headingPages"
             data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item<?php echo e(request()->is('kunjungan') ? ' active' : ''); ?>"
                   href="<?php echo e(route('kunjungan.index')); ?>"><?php echo e(__('layouts.index')); ?></a>

                <a class="collapse-item<?php echo e(request()->is('kunjungan/create') ? ' active' : ''); ?>"
                   href="<?php echo e(route('kunjungan.create')); ?>"><?php echo e(__('layouts.create')); ?></a>
            </div>
        </div>
    </li>






























    <hr class="sidebar-divider">

    <?php if(auth()->user()->roles === 'TU-PEGAWAI'): ?>
    <div class="sidebar-heading">
        <?php echo e(__('layouts.kelola_data')); ?>

    </div>

    <li class="nav-item<?php echo e(request()->is('pengguna') || request()->is('pengguna/*') ? ' active' : ''); ?>">
        <a class="nav-link<?php echo e(request()->is('pengguna') ? '' : ' collapsed'); ?>"
           href="javascript:void(0)" data-toggle="collapse" data-target="#pengguna" aria-expanded="false"
           aria-controls="pengguna">
            <i class="fas fa-fw fa-user"></i>
            <span><?php echo e(__('layouts.pengguna')); ?></span>
        </a>
        <div id="pengguna" class="collapse<?php echo e(request()->is('pengguna') || request()->is('pengguna/*') ? ' show' : ''); ?>"
             aria-labelledby="headingPages"
             data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item<?php echo e(request()->is('pengguna') ? ' active' : ''); ?>"
                   href="<?php echo e(route('pengguna.index')); ?>"><?php echo e(__('layouts.index')); ?></a>
                <a class="collapse-item<?php echo e(request()->is('pengguna/create') ? ' active' : ''); ?>"
                   href="<?php echo e(route('pengguna.create')); ?>"><?php echo e(__('layouts.create')); ?></a>
            </div>
        </div>
    </li>

    <li class="nav-item<?php echo e(request()->is('hakim') || request()->is('hakim/*') ? ' active' : ''); ?>">
        <a class="nav-link collapsed<?php echo e(request()->is('hakim') ? '' : ' collapsed'); ?>"
           href="javascript:void(0)" data-toggle="collapse" data-target="#hakim" aria-expanded="false"
           aria-controls="hakim">
            <i class="fas fa-fw fa-hammer"></i>
            <span><?php echo e(__('layouts.hakim')); ?></span>
        </a>
        <div id="hakim" class="collapse<?php echo e(request()->is('hakim') || request()->is('hakim/*') ? ' show' : ''); ?>"
             aria-labelledby="headingPages"
             data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">

                <a class="collapse-item<?php echo e(request()->is('hakim') ? ' active' : ''); ?>"
                   href="<?php echo e(route('hakim.index')); ?>"><?php echo e(__('layouts.index')); ?></a>

                <a class="collapse-item<?php echo e(request()->is('hakim/create') ? ' active' : ''); ?>"
                   href="<?php echo e(route('hakim.create')); ?>"><?php echo e(__('layouts.create')); ?></a>

            </div>
        </div>
    </li>

    <li class="nav-item<?php echo e(request()->is('jaksa')  || request()->is('jaksa/*')? ' active' : ''); ?>">
        <a class="nav-link collapsed" href="javascript:void(0)" data-toggle="collapse" data-target="#jaksa"
           aria-expanded="false"
           aria-controls="jaksa">
            <i class="fas fa-fw fa-people-arrows"></i>
            <span><?php echo e(__('layouts.jaksa')); ?></span>
        </a>
        <div id="jaksa" class="collapse<?php echo e(request()->is('jaksa') || request()->is('jaksa/*') ? ' show' : ''); ?>"
             aria-labelledby="headingPages"
             data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">

                <a class="collapse-item<?php echo e(request()->is('jaksa') ? ' active' : ''); ?>"
                   href="<?php echo e(route('jaksa.index')); ?>"><?php echo e(__('layouts.index')); ?></a>

                <a class="collapse-item<?php echo e(request()->is('jaksa/create') ? ' active' : ''); ?>"
                   href="<?php echo e(route('jaksa.create')); ?>"><?php echo e(__('layouts.create')); ?></a>
            </div>
        </div>
    </li>

    <li class="nav-item<?php echo e(request()->is('narapidana') || request()->is('narapidana/*') ? ' active' : ''); ?>">
        <a class="nav-link collapsed" href="javascript:void(0)" data-toggle="collapse" data-target="#narapidana"
           aria-expanded="false"
           aria-controls="narapidana">
            <i class="fas fa-fw fa-person-booth"></i>
            <span><?php echo e(__('layouts.narapidana')); ?></span>
        </a>
        <div id="narapidana" class="collapse<?php echo e(request()->is('narapidana') || request()->is('narapidana/*') ? ' show' : ''); ?>"
             aria-labelledby="headingPages"
             data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">

                <a class="collapse-item<?php echo e(request()->is('narapidana') ? ' active' : ''); ?>"
                   href="<?php echo e(route('narapidana.index')); ?>"><?php echo e(__('layouts.index')); ?></a>

                <a class="collapse-item<?php echo e(request()->is('narapidana/create') ? ' active' : ''); ?>"
                   href="<?php echo e(route('narapidana.create')); ?>"><?php echo e(__('layouts.create')); ?></a>

            </div>
        </div>
    </li>

    <li class="nav-item<?php echo e(request()->is('sidang') || request()->is('sidang/*')? ' active' : ''); ?>">
        <a class="nav-link collapsed" href="javascript:void(0)" data-toggle="collapse" data-target="#sidang"
           aria-expanded="false"
           aria-controls="sidang">
            <i class="fas fa-fw fa-person-booth"></i>
            <span><?php echo e(__('layouts.sidang')); ?></span>
        </a>
        <div id="sidang" class="collapse<?php echo e(request()->is('sidang') || request()->is('sidang/*') ? ' show' : ''); ?>"
             aria-labelledby="headingPages"
             data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">

                <a class="collapse-item<?php echo e(request()->is('sidang') ? ' active' : ''); ?>"
                   href="<?php echo e(route('sidang.index')); ?>"><?php echo e(__('layouts.index')); ?></a>

                <a class="collapse-item<?php echo e(request()->is('sidang/create') ? ' active' : ''); ?>"
                   href="<?php echo e(route('sidang.create')); ?>"><?php echo e(__('layouts.create')); ?></a>

            </div>
        </div>
    </li>

    <?php endif; ?>



























    <hr class="sidebar-divider">

    <!-- Sidebar Toggler -->
    <div class="text-center d-none d-md-inline mt-3">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>

</ul>
<?php /**PATH E:\PROJECTS\sinahan\APLIKASI\sinahan\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>