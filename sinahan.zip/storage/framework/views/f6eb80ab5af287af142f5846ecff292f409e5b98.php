

<?php $__env->startSection('title', 'Tambah Pengguna'); ?>

<?php $__env->startSection('desc', 'Anda dapat menambahkan pengguna baru dengan form dibawah ini.'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-6 col-xl-6">

            <div class="card mb-4">
                <div class="card-body">





                    <form>
                        <div class="form-group">
                            <label for="nama_lengkap">Nama Lengkap</label>
                            <input name="nama_lengkap" type="text" class="form-control" id="nama_lengkap">



                        </div>

                        <div class="form-group">
                            <label for="username">Username</label>
                            <input name="username" type="text" class="form-control" id="username" aria-describedby="username_help">



                        </div>

                        <div class="form-group">
                            <label for="roles">Sebagai</label>
                            <select name="roles" id="roles" class="form-control">
                                <option value="0" disabled selected>Pilih jenis pengguna</option>
                                <option value="0">ADMIN</option>
                                <option value="0">STAFF</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="password">Password</label>
                            <input name="password" type="password" class="form-control" id="password">
                        </div>

                        <div class="form-group">
                            <label for="password-confirmation">Konfirmasi Password</label>
                            <input name="password-confirmation" type="password" class="form-control" id="password-confirmation">
                        </div>

                        <div class="form-group">
                            <label for="foto">Foto</label>
                            <input name="foto" type="file" class="form-control-file" id="foto" aria-describedby="foto_help">



                        </div>


                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <a href="<?php echo e(route('pengguna.index')); ?>" type="submit" class="btn btn-secondary">Kembali</a>
                    </form>
                </div>
            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROJECTS\sinahan\APLIKASI\sinahan\resources\views/pages/pengguna/create.blade.php ENDPATH**/ ?>