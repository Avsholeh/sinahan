<?php $__env->startSection('title', 'Tambah Pengguna'); ?>

<?php $__env->startSection('desc', 'Anda dapat menambahkan pengguna baru dengan form dibawah ini.'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-6 col-xl-6">

            <div class="card mb-4">
                <div class="card-body">

                    <form action="<?php echo e(route('pengguna.store')); ?>" method="post">

                        <?php echo csrf_field(); ?>
                        <?php echo method_field('post'); ?>

                        
                        <div class="form-group">
                            <label for="nama_lengkap">Nama Lengkap</label>
                            <input name="nama_lengkap" type="text" class="form-control" id="nama_lengkap"
                                   value="<?php if(old('nama_lengkap')): ?> <?php echo e(old('nama_lengkap')); ?><?php endif; ?>"
                                   aria-describedby="nama_lengkap_help">

                            <?php $__errorArgs = ['nama_lengkap'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small id="nama_lengkap_help" class="form-text text-danger">
                                <i class="fa fa-info-circle"></i> <?php echo e($message); ?>

                            </small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="form-group">
                            <label for="username">Username</label>
                            <input name="username" type="text" class="form-control" id="username"
                                   value="<?php if(old('username')): ?> <?php echo e(old('username')); ?><?php endif; ?>"
                                   aria-describedby="username_help">

                            <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small id="username_help" class="form-text text-danger">
                                <i class="fa fa-info-circle"></i> <?php echo e($message); ?>

                            </small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="form-group">
                            <label class="control-label" for="jenis_kelamin">Jenis Kelamin</label>
                            <select class="form-control" name="jenis_kelamin"
                                    id="jenis_kelamin">
                                <option value="" readonly>Pilih jenis kelamin</option>
                                <option
                                    <?php if(old('jenis_kelamin') === 'laki-laki'): ?> <?php echo e('selected'); ?><?php endif; ?>
                                    value="laki-laki"
                                >Laki-laki</option>
                                <option
                                    <?php if(old('jenis_kelamin') === 'perempuan'): ?> <?php echo e('selected'); ?><?php endif; ?>
                                    value="perempuan"
                                >Perempuan</option>
                            </select>
                        </div>

                        
                        <div class="form-group">
                            <label for="roles">Sebagai</label>
                            <select name="roles" id="roles" class="form-control">
                                <option value="" readonly>Pilih jenis pengguna</option>
                                <option
                                    <?php if(old('roles') === 'TU-PEGAWAI'): ?> <?php echo e('selected'); ?><?php endif; ?>
                                    value="TU-PEGAWAI">TU-PEGAWAI</option>
                                <option
                                    <?php if(old('roles') === 'MASYARAKAT'): ?> <?php echo e('selected'); ?><?php endif; ?>
                                    value="MASYARAKAT">MASYARAKAT</option>
                            </select>
                        </div>

                        
                        <div class="form-group">
                            <label for="foto">Foto</label>
                            <input name="foto" type="file" class="form-control-file" id="foto"
                                   value="<?php if(old('foto')): ?> <?php echo e(old('foto')); ?><?php endif; ?>"
                                   aria-describedby="foto_help">

                            <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small id="foto_help" class="form-text text-danger">
                                <i class="fa fa-info-circle"></i> <?php echo e($message); ?>

                            </small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input name="password" type="password" class="form-control" id="password"
                                   value="<?php if(old('password')): ?> <?php echo e(old('password')); ?><?php endif; ?>"
                                   aria-describedby="password_help">

                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small id="password_help" class="form-text text-danger">
                                <i class="fa fa-info-circle"></i> <?php echo e($message); ?>

                            </small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="form-group">
                            <label for="password_confirmation">Konfirmasi Password</label>
                            <input name="password_confirmation" type="password" class="form-control"
                                   id="password_confirmation">

                            <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small id="password_confirmation_help" class="form-text text-danger">
                                <i class="fa fa-info-circle"></i> <?php echo e($message); ?>

                            </small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <hr>

                        <button type="submit" class="btn btn-primary mt-3">Simpan Perubahan</button>
                    </form>
                </div>
            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROJECTS\sinahan\APLIKASI\sinahan\resources\views/pages/pengguna/create.blade.php ENDPATH**/ ?>