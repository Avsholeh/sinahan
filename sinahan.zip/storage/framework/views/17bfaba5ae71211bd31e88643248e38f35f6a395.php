<?php $__env->startSection('title', 'Tambah Hakim'); ?>

<?php $__env->startSection('desc', 'Anda dapat menambahkan Hakim dengan form dibawah ini.'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-8 col-lg-8 col-xl-6">

            <div class="card mb-4">
                <div class="card-body">
                    <form action="<?php echo e(route('hakim.store')); ?>" method="post" enctype="multipart/form-data">

                        <?php echo csrf_field(); ?>
                        <?php echo method_field('post'); ?>

                        
                        <div class="form-group">
                            <label for="nama_lengkap">Nama Lengkap</label>
                            <input name="nama_lengkap" type="text" class="form-control" id="nama_lengkap"
                                   value="<?php if(old('nama_lengkap')): ?> <?php echo e(old('nama_lengkap')); ?><?php endif; ?>"
                                   aria-describedby="username_help">

                            <?php $__errorArgs = ['nama_lengkap'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small id="nama_lengkap_help" class="form-text text-danger">
                                <i class="fa fa-info-circle"></i> <?php echo e($message); ?>

                            </small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="form-group">
                            <label for="nip">NIP</label>
                            <input name="nip" type="number" class="form-control" id="nip"
                                   value="<?php if(old('nip')): ?><?php echo e(old('nip')); ?><?php endif; ?>"
                                   aria-describedby="nip_help">

                            <?php $__errorArgs = ['nip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small id="nip_help" class="form-text text-danger">
                                <i class="fa fa-info-circle"></i> <?php echo e($message); ?>

                            </small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="form-group">
                            <label for="tempat_lahir">Tempat Lahir</label>
                            <input name="tempat_lahir" type="text" class="form-control" id="tempat_lahir"
                                   value="<?php if(old('tempat_lahir')): ?><?php echo e(old('tempat_lahir')); ?><?php endif; ?>"
                                   aria-describedby="tempat_lahir_help">

                            <?php $__errorArgs = ['tempat_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small id="tempat_lahir_help" class="form-text text-danger">
                                <i class="fa fa-info-circle"></i> <?php echo e($message); ?>

                            </small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="form-group">
                            <label for="tanggal_lahir">Tanggal Lahir</label>
                            <input name="tanggal_lahir" type="date" class="form-control" id="tanggal_lahir"
                                   value="<?php if(old('tanggal_lahir')): ?><?php echo e(old('tanggal_lahir')); ?><?php endif; ?>">

                            <?php $__errorArgs = ['tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small id="tanggal_lahir_help" class="form-text text-danger">
                                <i class="fa fa-info-circle"></i> <?php echo e($message); ?>

                            </small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="form-group">
                            <label for="pangkat_golongan">Pangkat/Golongan</label>
                            <select name="pangkat_golongan" id="pangkat_golongan" class="form-control">
                                <option disabled selected>Pilih pangkat/golongan</option>
                                <option value="I A - Juru Muda">I A - Juru Muda</option>
                                <option value="I B - Juru Muda Tingkat 1">I B - Juru Muda Tingkat 1</option>
                                <option value="I C - Juru">I C - Juru</option>
                                <option value="I D - Juru Tingkat 1">I D - Juru Tingkat 1</option>
                                <option value="II A - Pengatur Muda">II A - Pengatur Muda</option>
                                <option value="II B - Pengatur Muda Tingkat 1">II B - Pengatur Muda Tingkat 1</option>
                                <option value="II C - Pengatur">II C - Pengatur</option>
                                <option value="II D - Pengatur Tingkat 1">II D - Pengatur Tingkat 1</option>
                                <option value="III A - Penata Muda">III A - Penata Muda</option>
                                <option value="III B - Penata Muda Tingkat 1">III B - Penata Muda Tingkat 1</option>
                                <option value="III C - Penata">III C - Penata</option>
                                <option value="III D - Penata Tingkat 1">III D - Penata Tingkat 1</option>
                                <option value="IV A - Pembina">IV A - Pembina</option>
                                <option value="IV B - Pembina Tingkat 1">IV B - Pembina Tingkat 1</option>
                                <option value="IV C - Pembina Utama Muda">IV C - Pembina Utama Muda</option>
                                <option value="IV D - Pembina Utama Madya">IV D - Pembina Utama Madya</option>
                                <option value="IV E - Pembina Utama">IV E - Pembina Utama</option>
                            </select>

                            <?php $__errorArgs = ['pangkat_golongan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small id="pangkat_golongan_help" class="form-text text-danger">
                                <i class="fa fa-info-circle"></i> <?php echo e($message); ?>

                            </small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="form-group">
                            <label for="agama">Agama</label>
                            <select name="agama" id="agama" class="form-control" aria-describedby="agama_help">
                                <option value="" readonly>Pilih agama</option>
                                <option value="Islam" <?php if(old('agama') === 'Islam'): ?><?php echo e('selected'); ?><?php endif; ?>>
                                    Islam
                                </option>
                                <option value="Kristen" <?php if(old('agama') === 'Kristen'): ?><?php echo e('selected'); ?><?php endif; ?>>
                                    Kristen
                                </option>
                                <option value="Budha" <?php if(old('agama') === 'Budha'): ?><?php echo e('selected'); ?><?php endif; ?>>
                                    Budha
                                </option>
                                <option value="Hindu" <?php if(old('agama') === 'Hindu'): ?><?php echo e('selected'); ?><?php endif; ?>>
                                    Hindu
                                </option>
                                <option value="Konghucu" <?php if(old('agama') === 'Konghucu'): ?><?php echo e('selected'); ?><?php endif; ?>>
                                    Konghucu
                                </option>
                            </select>

                            <?php $__errorArgs = ['agama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small id="agama_help" class="form-text text-danger">
                                <i class="fa fa-info-circle"></i> <?php echo e($message); ?>

                            </small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="form-group">
                            <label for="jenis_kelamin">Jenis Kelamin</label>
                            <select name="jenis_kelamin" id="jenis_kelamin" class="form-control">
                                <option value="" readonly>Pilih jenis kelamin</option>
                                <option
                                    value="Laki-Laki" <?php if(old('jenis_kelamin') === 'Pria'): ?> <?php echo e('selected'); ?> <?php endif; ?>>
                                    Pria
                                </option>
                                <option
                                    value="Perempuan" <?php if(old('jenis_kelamin') === 'Wanita'): ?> <?php echo e('selected'); ?> <?php endif; ?>>
                                    Wanita
                                </option>
                            </select>

                            <?php $__errorArgs = ['jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small id="jenis_kelamin_help" class="form-text text-danger">
                                <i class="fa fa-info-circle"></i> <?php echo e($message); ?>

                            </small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="form-group">
                            <label for="pendidikan">Pendidikan Terakhir</label>
                            <input name="pendidikan" type="text" class="form-control" id="pendidikan"
                                   value="<?php if(old('pendidikan')): ?> <?php echo e(old('pendidikan')); ?><?php endif; ?>">

                            <?php $__errorArgs = ['pendidikan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small id="pendidikan_help" class="form-text text-danger">
                                <i class="fa fa-info-circle"></i> <?php echo e($message); ?>

                            </small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="form-group">
                            <label for="status">Status</label>
                            <select name="status" id="status" class="form-control">
                                <option value="" readonly>Pilih status</option>
                                <option value="Aktif" <?php if(old('status') === 'Aktif'): ?><?php echo e('selected'); ?><?php endif; ?>>Aktif
                                </option>
                                <option value="Tidak Aktif" <?php if(old('status') === 'Tidak Aktif'): ?><?php echo e('selected'); ?><?php endif; ?>>
                                    Tidak Aktif
                                </option>
                            </select>

                            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small id="status_help" class="form-text text-danger">
                                <i class="fa fa-info-circle"></i> <?php echo e($message); ?>

                            </small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="form-group">
                            <label for="foto">Upload foto</label>
                            <input name="foto" type="file" class="form-control-file" id="foto"
                                   value="<?php if(old('foto')): ?> <?php echo e(old('foto')); ?><?php endif; ?>">

                            <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small id="foto_help" class="form-text text-danger">
                                <i class="fa fa-info-circle"></i> <?php echo e($message); ?>

                            </small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <a href="<?php echo e(route('hakim.index')); ?>" type="submit" class="btn btn-secondary">Kembali</a>
                    </form>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROJECTS\sinahan\APLIKASI\sinahan\resources\views/pages/hakim/create.blade.php ENDPATH**/ ?>