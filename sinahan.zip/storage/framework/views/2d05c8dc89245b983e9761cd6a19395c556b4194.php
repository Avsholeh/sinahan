<?php $__env->startSection('title', 'Jaksa'); ?>

<?php $__env->startSection('content'); ?>

    <div class="card mb-4">
        <div class="card-body p-3">
            <div class="row mb-4">
                <div class="col">
                    <a href="<?php echo e(route('jaksa.create')); ?>" class="btn btn-primary">Tambah Baru</a>
                </div>
            </div>

            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success"><?php echo e($message); ?></div>
            <?php endif; ?>

            <div class="table-responsive overflow-auto">
                <table class="table table-bordered" id="dataTable">
                    <thead>
                    <tr>
                        <th>Foto</th>
                        <th>Nama Lengkap</th>
                        <th>NIP</th>
                        <th>Tempat Lahir</th>
                        <th>Tanggal Lahir</th>
                        <th>Pangkat</th>
                        <th>Golongan</th>
                        <th>Jabatan</th>
                        <th>Agama</th>
                        <th>Jenis Kelamin</th>
                        <th>Pendidikan</th>
                        <th>Status</th>
                        <th>#</th>
                    </tr>
                    </thead>
                    <tbody>

                    <?php $__currentLoopData = $jaksas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jaksa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <td>
                                <div class="rounded-circle"
                                     style="width: 50px; height: 50px; background-image: url('data:image/png;base64,<?php echo e($jaksa->foto); ?>'); background-size: cover"></div>
                            </td>
                            <td><?php echo e($jaksa->nama_lengkap); ?></td>
                            <td><?php echo e($jaksa->nip); ?></td>
                            <td><?php echo e($jaksa->tempat_lahir); ?></td>
                            <td><?php echo e($jaksa->tanggal_lahir); ?></td>
                            <td><?php echo e($jaksa->pangkat); ?></td>
                            <td><?php echo e($jaksa->golongan); ?></td>
                            <td><?php echo e($jaksa->jabatan); ?></td>
                            <td><?php echo e($jaksa->agama); ?></td>
                            <td><?php echo e($jaksa->jenis_kelamin); ?></td>
                            <td><?php echo e($jaksa->pendidikan); ?></td>
                            <td>
                                <?php if($jaksa->status === \App\Models\Jaksa::AKTIF): ?>
                                    <div class="badge badge-success"><?php echo e($jaksa->status); ?></div>
                                <?php else: ?>
                                    <div class="badge badge-danger"><?php echo e($jaksa->status); ?></div>
                                <?php endif; ?>
                            </td>

                            <td class="d-flex flex-row">
                                <a href="<?php echo e(route('jaksa.edit', $jaksa->id)); ?>" class="btn btn-warning btn-sm text-dark mr-2">
                                    <?php echo e(__('layouts.update')); ?>

                                </a>
                                
                                <a href="#" class="btn btn-danger btn-sm btn-delete" data-toggle="modal"
                                   data-target="#hapusModal">
                                    <?php echo e(__('layouts.delete')); ?>

                                </a>
                                <form id="form-delete-<?php echo e($jaksa->id); ?>"
                                      action="<?php echo e(route('jaksa.delete', $jaksa->id)); ?>"
                                      method="post" hidden>
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                </form>
                                
                            </td>
                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Hapus Modal-->
    <div class="modal fade" id="hapusModal" tabindex="-1" role="dialog" aria-labelledby="hapusModalLabel"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="hapusModalLabel">Apakah anda yakin ?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    Jika anda memilih untuk menghapus, maka data akan dihapus dari penyimpanan dan
                    tidak dapat dikembalikan.
                </div>

                
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Batalkan</button>
                    <a id="konfirmasi" class="btn btn-primary" href="javascript:void(0)">Konfirmasi</a>
                </div>
                

                <form id="form-delete" action="#" method="post" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script>
        $(document).ready(function () {
            $('#dataTable').DataTable();

            $('.btn-delete').click(function (e) {
                e.preventDefault();
                var $siblings = $(this).siblings();
                console.log($siblings);
                $('#konfirmasi').click(function (e) {
                    e.preventDefault();
                    // should check type of siblings
                    // if sibling is not a form
                    // then ignore it
                    $siblings[1].submit();
                });
            });
        });
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROJECTS\sinahan\APLIKASI\sinahan\resources\views/pages/jaksa/index.blade.php ENDPATH**/ ?>