

<?php $__env->startSection('title', 'Tambah Kunjungan'); ?>

<?php $__env->startSection('desc', 'Anda dapat menambahkan Kunjungan dengan form dibawah ini.'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-6 col-xl-6">
            <!-- KUNJUNGAN -->
            <div class="card mb-4">
                <div class="card-body">
                    <form>
                        <div class="form-group">
                            <label for="narapidana">Narapidana</label>
                            <select name="narapidana" id="narapidana" class="form-control">
                                <option disabled selected>Narapidana yang akan dikunjungi</option>
                                <?php $faker = \Faker\Factory::create(); $index = 1  ?>

                                <?php while($index < 100): ?>
                                <option value="0"><?php echo e($faker->name); ?></option>
                                <?php $index++ ?>
                                <?php endwhile; ?>

                            </select>
                        </div>

                        <div class="form-group">
                            <label for="berlaku">Berlaku Hingga</label>
                            <input name="berlaku" type="date" class="form-control" id="berlaku"
                                   aria-describedby="berlaku" value="" disabled>
                        </div>

                        <div class="form-group">
                            <label for="keperluan">Keperluan</label>
                            <textarea name="keperluan" class="form-control" id="keperluan" cols="30" rows="3"
                                      aria-describedby="keperluan"></textarea>
                        </div>

                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <a href="<?php echo e(route('kunjungan.index')); ?>" type="submit" class="btn btn-secondary">Kembali</a>
                    </form>
                </div>
            </div>
            <!-- END KUNJUNGAN -->
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROJECTS\sinahan\APLIKASI\sinahan\resources\views/pages/kunjungan/create.blade.php ENDPATH**/ ?>