

<?php $__env->startSection('title', 'Sidang'); ?>

<?php $__env->startSection('content'); ?>

    <div class="card mb-4">
        <div class="card-body p-3">
            <div class="row mb-5">
                <div class="col">
                    <button class="btn btn-primary">Tambah Baru</button>
                </div>
            </div>
            <div class="table-responsive overflow-auto">
                <table class="table table-bordered" id="dataTable">
                    <thead>
                    <tr>
                        <th>Tanggal</th>
                        <th>Narapidana</th>
                        <th>Pasal</th>
                        <th>JPU</th>
                        <th>Hakim</th>
                        <th>Keterangan</th>
                        <th>#</th>
                    </tr>
                    </thead>
                    <tbody>

                    <?php $faker = \Faker\Factory::create() ?>

                    <?php $__currentLoopData = [1,2,3,4,5]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <td><?php echo e($faker->date); ?></td>
                            <td><?php echo e($faker->name); ?></td>
                            <td><?php echo e($faker->randomElement(['UU RI No. 17/2006', 'UU RI No. 35/2006', 'UU RI No. 35/2009' ])); ?></td>
                            <td><?php echo e($faker->name); ?>, S.H</td>
                            <td><?php echo e($faker->name); ?>, S.H</td>
                            <td><?php echo e($faker->randomElement(['Tuntutan', 'Pledoi', 'Ket.Saksi'])); ?></td>
                            <td class="d-flex flex-row">
                                <a href="<?php echo e(route('sidang.edit', 1)); ?>" class="btn btn-warning btn-sm text-dark mr-2">
                                    <?php echo e(__('layouts.update')); ?>

                                </a>
                                <a class="btn btn-danger btn-sm" data-toggle="modal" data-target="#hapusModal">
                                    <?php echo e(__('layouts.delete')); ?>

                                </a>
                            </td>
                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Hapus Modal-->
    <div class="modal fade" id="hapusModal" tabindex="-1" role="dialog" aria-labelledby="hapusModalLabel"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="hapusModalLabel">Apakah anda yakin ?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Jika anda memilih untuk menghapus, maka data akan dihapus dari penyimpanan dan
                    tidak dapat dikembalikan.
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Batalkan</button>
                    <a class="btn btn-primary" href="javascript:void(0)"
                       onclick="event.preventDefault(); document.getElementById('form-delete').submit()"
                    >Konfirmasi</a>
                </div>
                <form id="form-delete" action="#" method="post" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script>
    $(document).ready(function() {
        $('#dataTable').DataTable();
    });
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROJECTS\sinahan\APLIKASI\sinahan\resources\views/pages/sidang/index.blade.php ENDPATH**/ ?>