

<?php $__env->startSection('title', 'Biodata'); ?>

<?php $__env->startSection('desc', 'Anda dapat memperbarui biodata dengan form dibawah ini.'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-6 col-xl-6">

            <div class="card shadow mb-4">
                <div class="card-body">



                    <form>
                        <div class="form-group">
                            <label for="nama_lengkap">Nama Lengkap</label>
                            <input type="text" class="form-control" id="nama_lengkap"
                                value="<?php echo e(auth()->user()->nama_lengkap); ?>">



                        </div>

                        
                        <div class="form-group">
                            <label class="control-label" for="jenis_kelamin">Jenis Kelamin</label>
                            <select class="form-control" name="jenis_kelamin"
                                    id="jenis_kelamin">
                                <option disabled>Pilih jenis kelamin</option>

                                <?php if(auth()->user()->jenis_kelamin === 'laki-laki'): ?>

                                <option selected value="laki-laki">Laki-laki</option>
                                <option value="perempuan">Perempuan</option>

                                <?php else: ?>

                                <option value="laki-laki">Laki-laki</option>
                                <option selected value="perempuan">Perempuan</option>

                                <?php endif; ?>

                            </select>
                        </div>

                        <div class="form-group">
                            <label for="username">Username</label>
                            <input type="text" class="form-control" id="username"
                                   value="<?php echo e(auth()->user()->username); ?>" disabled>



                        </div>

                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" class="form-control" id="password"
                                   value="password" aria-describedby="password_help">



                        </div>


                        <div class="form-group">
                            <label for="foto">Foto</label>
                            <input type="file" class="form-control-file" id="foto" aria-describedby="foto_help">



                        </div>

                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </form>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROJECTS\sinahan\APLIKASI\sinahan\resources\views/pages/biodata/edit.blade.php ENDPATH**/ ?>