<?php $__env->startSection('title', 'Perbarui Pengguna'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-6 col-xl-6">

            <div class="card shadow mb-4">
                <div class="card-body">

                    <form action="<?php echo e(route('pengguna.update', $pengguna->id)); ?>" method="post">

                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>

                        
                        <div class="form-group">
                            <label for="nama_lengkap">Nama Lengkap</label>
                            <input name="nama_lengkap" type="text" class="form-control" id="nama_lengkap"
                                   value="<?php echo e($pengguna->nama_lengkap); ?>"
                                   aria-describedby="nama_lengkap_help">

                            <?php $__errorArgs = ['nama_lengkap'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small id="nama_lengkap_help" class="form-text text-danger">
                                <i class="fa fa-info-circle"></i> <?php echo e($message); ?>

                            </small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="form-group">
                            <label for="username">Username</label>
                            <input name="username" type="text" class="form-control" id="username"
                                   value="<?php echo e($pengguna->username); ?>"
                                   aria-describedby="username_help">

                            <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small id="username_help" class="form-text text-danger">
                                <i class="fa fa-info-circle"></i> <?php echo e($message); ?>

                            </small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="form-group">
                            <label class="control-label" for="jenis_kelamin">Jenis Kelamin</label>
                            <select class="form-control" name="jenis_kelamin"
                                    id="jenis_kelamin">
                                <option disabled>Pilih jenis kelamin</option>

                                <?php if(auth()->user()->jenis_kelamin === 'laki-laki'): ?>

                                    <option selected value="laki-laki">Laki-laki</option>
                                    <option value="perempuan">Perempuan</option>

                                <?php else: ?>

                                    <option value="laki-laki">Laki-laki</option>
                                    <option selected value="perempuan">Perempuan</option>

                                <?php endif; ?>

                            </select>
                        </div>

                        
                        <div class="form-group">
                            <label for="roles">Sebagai</label>
                            <select name="roles" id="roles" class="form-control">
                                <option value="" disabled>Pilih jenis pengguna</option>

                                <?php if($pengguna->roles === 'TU-PEGAWAI'): ?>

                                    <option selected value="TU-PEGAWAI">TU-PEGAWAI</option>
                                    <option value="MASYARAKAT">MASYARAKAT</option>

                                <?php else: ?>

                                    <option value="TU-PEGAWAI">TU-PEGAWAI</option>
                                    <option selected value="MASYARAKAT">MASYARAKAT</option>

                                <?php endif; ?>
                            </select>
                        </div>

                        
                        <div class="form-group">
                            <label for="foto">Foto</label>
                            <input name="foto" type="file" class="form-control-file" id="foto"
                                   aria-describedby="foto_help">

                            <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small id="foto_help" class="form-text text-danger">
                                <i class="fa fa-info-circle"></i> <?php echo e($message); ?>

                            </small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input name="password" type="password" class="form-control" id="password"
                                   value="password"
                                   aria-describedby="password_help">

                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small id="password_help" class="form-text text-danger">
                                <i class="fa fa-info-circle"></i> <?php echo e($message); ?>

                            </small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="form-group">
                            <label for="password_confirmation">Konfirmasi Password</label>
                            <input name="password_confirmation" type="password" class="form-control"
                                   value="password"
                                   id="password_confirmation">

                            <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small id="password_confirmation_help" class="form-text text-danger">
                                <i class="fa fa-info-circle"></i> <?php echo e($message); ?>

                            </small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <hr>

                        <button type="submit" class="btn btn-primary mt-3">Simpan Perubahan</button>
                    </form>
                </div>
            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROJECTS\sinahan\APLIKASI\sinahan\resources\views/pages/pengguna/edit.blade.php ENDPATH**/ ?>