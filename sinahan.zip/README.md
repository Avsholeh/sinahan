# ?

### Fitur Utama 🏅

1. Manajemen User
2. Manajemen Roles/Group/Jabatan
3. Kunjungan
4. Sidang
5. Jaksa
6. Narapidana

### Fitur Tambahan 🎖️

##### ▶️ Export PDF

-   x

##### ▶️ Print PDF

-   x

### Roadmap 🗺️
- Desain layout
- Menambahkan Menu Manajemen User
- Menambahkan Menu Manajemen Roles
- Menambahkan Menu Manajemen Permission
